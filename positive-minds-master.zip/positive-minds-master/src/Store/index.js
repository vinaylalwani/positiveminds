import Store from './store';
export default Store;