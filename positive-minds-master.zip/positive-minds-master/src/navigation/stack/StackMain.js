import React from 'react'
import { Text } from 'react-native'
import DrawerNavigator from '../drawer/DrawerNavigation';

function StackMain() {
  return (
    <DrawerNavigator />
  )
}

export default StackMain;