import Quotes from './Quotes'
export default Quotes;