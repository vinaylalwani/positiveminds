import AuthLoadingScreen from './AuthLoadingScreen';
export default AuthLoadingScreen;
