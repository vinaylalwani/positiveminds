import React from 'react'
import { Text } from 'react-native'

function Meditation() {
  return (
    <Text>Meditation</Text>
  )
}

export default Meditation