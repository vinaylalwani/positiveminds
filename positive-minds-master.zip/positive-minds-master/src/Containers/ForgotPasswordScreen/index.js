import ForgotPasswordScreen from './ForgotPasswordScreen';
export default ForgotPasswordScreen;
