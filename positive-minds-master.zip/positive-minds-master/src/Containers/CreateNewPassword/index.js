import CreateNewPassword from './CreateNewPassword';
export default CreateNewPassword;
