import Articles from './Articles'
export default Articles;