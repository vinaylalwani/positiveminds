import { StyleSheet, Dimensions } from "react-native"
import { Colors } from "../../Theme"

export default StyleSheet.create({
  container: {
    backgroundColor:'white',
    flex: 1,
    margin: 0,
}
})