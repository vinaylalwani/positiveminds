import ProfileScreen from './ProfileScreen';
export default ProfileScreen;
