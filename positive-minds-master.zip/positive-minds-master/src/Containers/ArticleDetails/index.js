import ArticleDetails from './ArticleDetails'
export default ArticleDetails;