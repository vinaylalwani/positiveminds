export const ConfigDev = {
  API_URL: 'http://ec2-34-207-135-70.compute-1.amazonaws.com:3000/',
  // IOS_BUNDLE_ID: 'com.positiveminds',
  // IOS_APP_STORE_ID: '123456789',
  // IOS_MINIMUM_VERSION_ID: '0.0.26',
  // ANDROID_PACKAGE_NAME: 'com.positiveminds',
  ENV: 'DEV',
  APP_VERSION: '0.0.3-staging',
  RELEASE_DATE: '24.08.05.1',
};
