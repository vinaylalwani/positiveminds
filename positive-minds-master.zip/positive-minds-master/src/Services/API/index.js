import { postApi, getApi, deleteApi, putApi, postFormDataApi } from './API';

export { postApi, getApi, deleteApi, putApi, postFormDataApi } from './API';
