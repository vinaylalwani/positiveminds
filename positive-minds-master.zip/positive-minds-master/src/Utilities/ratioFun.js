const ratioFun = size => {
  return size / 1.33;
};

export { ratioFun };
