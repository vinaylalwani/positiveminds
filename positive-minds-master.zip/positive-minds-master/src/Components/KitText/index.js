import {KitText} from './KitText';

export {KitText};
