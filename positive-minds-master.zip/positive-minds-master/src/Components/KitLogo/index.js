import {KitLogo} from './KitLogo';

export {KitLogo};
