import {KitVideoPlayer} from './KitVideoPlayer';

export {KitVideoPlayer};
